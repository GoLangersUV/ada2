Dynamic Programming and Greedy Algorithms Application

To run the application:
1. Double-click on the executable file (app-linux).
2. Open your web browser and go to http://localhost:3000

The application will start both the backend server (on port 8080) and serve the frontend (on port 3000).

Note: If your firewall prompts you, please allow the application to access the network.
